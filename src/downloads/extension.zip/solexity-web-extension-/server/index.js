const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const axios = require('axios');

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// MongoDB Connection
const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('MongoDB connected successfully');
  } catch (error) {
    console.error('MongoDB connection error:', error.message);
    process.exit(1);
  }
};

// Simple schema to log questions
const questionSchema = new mongoose.Schema({
  question: { type: String, required: true },
  answer: { type: String, required: true },
  timestamp: { type: Date, default: Date.now }
});

const Question = mongoose.model('Question', questionSchema);

// Ollama configuration
const OLLAMA_BASE_URL = process.env.OLLAMA_BASE_URL || 'http://localhost:11434';
const QWEN_MODEL = process.env.QWEN_MODEL || 'qwen3-vl:235b-cloud';

// Function to query Qwen3-VL via Ollama
const queryQwenVL = async (prompt, images = []) => {
  try {
    console.log(`🤖 Querying Qwen3-VL model: ${QWEN_MODEL}`);
    
    const requestBody = {
      model: QWEN_MODEL,
      prompt: prompt,
      stream: false
    };

    // Add images if provided
    if (images.length > 0) {
      requestBody.images = images.map(img => 
        img.replace(/^data:image\/[^;]+;base64,/, '')
      );
    }

    console.log('Sending request to Ollama...');
    const response = await axios.post(`${OLLAMA_BASE_URL}/api/generate`, requestBody, {
      headers: {
        'Content-Type': 'application/json'
      },
      timeout: 120000 // 120 second timeout for large models
    });

    console.log('Ollama response received:', {
      status: response.status,
      hasData: !!response.data,
      keys: response.data ? Object.keys(response.data) : 'no data'
    });

    // Handle different possible response formats from Ollama
    if (response.data) {
      if (response.data.response !== undefined) {
        return response.data.response;
      } else if (response.data.message && response.data.message.content) {
        // Some models might use this format
        return response.data.message.content;
      } else if (response.data.content) {
        // Alternative format
        return response.data.content;
      } else {
        console.error('Unexpected response format:', JSON.stringify(response.data, null, 2));
        throw new Error('Unexpected response format from Ollama');
      }
    } else {
      throw new Error('No response data received from Ollama');
    }
  } catch (error) {
    console.error('❌ Error querying Qwen3-VL:', error.message);
    
    if (error.code === 'ECONNREFUSED') {
      throw new Error('Ollama server not running. Please start Ollama on localhost:11434');
    } else if (error.response) {
      console.error('Ollama API error details:', {
        status: error.response.status,
        data: error.response.data
      });
      
      if (error.response.status === 404) {
        throw new Error(`Model ${QWEN_MODEL} not found. Please install it with: ollama pull ${QWEN_MODEL}`);
      } else {
        throw new Error(`Ollama API error (${error.response.status}): ${JSON.stringify(error.response.data)}`);
      }
    } else {
      throw new Error(`Network error: ${error.message}`);
    }
  }
};

// Test Ollama connection and model availability
const testOllamaConnection = async () => {
  try {
    console.log('🔌 Testing Ollama connection...');
    const response = await axios.get(`${OLLAMA_BASE_URL}/api/tags`, {
      timeout: 10000
    });
    
    console.log('✅ Ollama connection successful');
    const models = response.data.models || [];
    console.log(`📋 Available models: ${models.map(m => m.name).join(', ')}`);
    
    const hasQwenModel = models.some(m => m.name.includes('qwen'));
    if (!hasQwenModel) {
      console.warn('⚠️ Qwen model not found in available models. Please install with: ollama pull qwen3-vl:235b-cloud');
    } else {
      console.log('✅ Qwen model found');
    }
    
    return true;
  } catch (error) {
    console.error('❌ Ollama connection test failed:', error.message);
    return false;
  }
};

// AI API function for text queries
const queryAI = async (question) => {
  try {
    return await queryQwenVL(question);
  } catch (error) {
    console.error('AI query failed:', error.message);
    
    // Final fallback
    return `I'm currently unable to process your request due to: ${error.message}. Please ensure Ollama is running and the Qwen3-VL model is installed.`;
  }
};

// Analyze image using Qwen3-VL
const analyzeImageAI = async (base64Image, prompt) => {
  try {
    const analysisPrompt = prompt || 'Provide a concise description of this image. Do not use bold text. Focus only on the main image, not on any article-type text surrounding it.';
    return await queryQwenVL(analysisPrompt, [base64Image]);
  } catch (error) {
    console.error('Image analysis failed:', error.message);
    return `Image analysis failed: ${error.message}. Please check that Ollama is running and the Qwen3-VL model supports image processing.`;
  }
};

// Routes
app.get('/', (req, res) => {
  res.json({ 
    message: 'Solexity AI Assistant Backend is running!', 
    status: 'active',
    ai_provider: 'Qwen3-VL via Ollama',
    model: QWEN_MODEL,
    ollama_url: OLLAMA_BASE_URL,
    endpoints: {
      ask: 'POST /ask - Send a question to get AI response',
      summarize: 'POST /summarize - { text } -> AI summary',
      analyzeImage: 'POST /analyze-image - { imageBase64, prompt? } -> AI description'
    }
  });
});

app.post('/ask', async (req, res) => {
  try {
    const { question } = req.body;

    if (!question || typeof question !== 'string' || question.trim().length === 0) {
      return res.status(400).json({ 
        error: 'Question is required and must be a non-empty string' 
      });
    }

    console.log('📝 Received question:', question.substring(0, 100) + '...');

    const answer = await queryAI(question.trim());

    // Save to database
    try {
      const questionDoc = new Question({
        question: question.trim(),
        answer: answer
      });
      await questionDoc.save();
      console.log('💾 Question and answer saved to database');
    } catch (dbError) {
      console.warn('⚠️ Failed to save to database:', dbError.message);
    }

    res.json({ answer });
    console.log('✅ Response sent successfully');

  } catch (error) {
    console.error('🔥 Error in /ask endpoint:', error.message);
    res.status(500).json({ 
      error: `Internal server error: ${error.message}` 
    });
  }
});

// Summarize route
app.post('/summarize', async (req, res) => {
  try {
    const { text } = req.body;

    if (!text || typeof text !== 'string' || text.trim().length === 0) {
      return res.status(400).json({ error: 'text is required and must be a non-empty string' });
    }

    const prompt = `Summarize the following text in bullet points, focusing on key insights and being concise. Do not use bold text.\n\nText:\n${text.trim()}`;
    const answer = await queryAI(prompt);
    
    try {
      const doc = new Question({ question: `Summarize: ${text.substring(0, 100)}...`, answer });
      await doc.save();
    } catch (e) {
      console.warn('⚠️ Failed to save summarize history:', e.message);
    }
    
    res.json({ summary: answer });
  } catch (error) {
    console.error('🔥 Error in /summarize:', error.message);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Analyze image route
app.post('/analyze-image', async (req, res) => {
  try {
    const { imageBase64, prompt } = req.body;
    if (!imageBase64 || typeof imageBase64 !== 'string') {
      return res.status(400).json({ error: 'imageBase64 is required (data URL or base64 string)' });
    }

    console.log('🖼️ Analyzing image, size:', Math.round(imageBase64.length / 1024), 'KB');
    const description = await analyzeImageAI(imageBase64, prompt);
    
    try {
      const doc = new Question({ 
        question: prompt ? `[image] ${prompt}` : '[image analysis]', 
        answer: description 
      });
      await doc.save();
    } catch (e) {
      console.warn('⚠️ Failed to save analyze-image history:', e.message);
    }
    
    res.json({ description });
  } catch (error) {
    console.error('🔥 Error in /analyze-image:', error.message);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// History (latest first)
app.get('/history', async (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit || '20', 10) || 20, 100);
    const items = await Question.find({}).sort({ timestamp: -1 }).limit(limit).lean();
    res.json({ items });
  } catch (e) {
    console.error('🔥 Error in /history:', e.message);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Ollama health check endpoint
app.get('/ollama-health', async (req, res) => {
  try {
    const response = await axios.get(`${OLLAMA_BASE_URL}/api/tags`, {
      timeout: 5000
    });
    
    const models = response.data.models || [];
    const qwenModel = models.find(m => m.name.includes('qwen'));
    
    res.json({ 
      status: 'healthy',
      ollama: 'connected',
      model_available: !!qwenModel,
      model_details: qwenModel,
      available_models: models.map(m => m.name),
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(503).json({ 
      status: 'unhealthy',
      ollama: 'disconnected',
      error: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// Health check endpoint
app.get('/health', async (req, res) => {
  const ollamaHealth = await testOllamaConnection();
  
  res.json({ 
    status: ollamaHealth ? 'healthy' : 'degraded',
    timestamp: new Date().toISOString(),
    database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
    ollama: ollamaHealth ? 'connected' : 'disconnected',
    ai_provider: 'Qwen3-VL via Ollama'
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('🔥 Unhandled error:', err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// Handle 404
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint not found' });
});

// Start server
const startServer = async () => {
  try {
    // Connect to database first
    await connectDB();
    
    // Test Ollama connection
    await testOllamaConnection();
    
    // Start listening
    app.listen(PORT, () => {
      console.log(`🚀 Solexity backend server running on port ${PORT}`);
      console.log(`🤖 AI Provider: Qwen3-VL via Ollama`);
      console.log(`📍 Health check: http://localhost:${PORT}/health`);
      console.log(`🔬 Ollama health: http://localhost:${PORT}/ollama-health`);
      console.log(`📚 API docs: http://localhost:${PORT}/`);
    });
  } catch (error) {
    console.error('💥 Failed to start server:', error.message);
    process.exit(1);
  }
};

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log('\n🛑 Graceful shutdown initiated...');
  try {
    await mongoose.connection.close();
    console.log('✅ MongoDB connection closed');
    process.exit(0);
  } catch (error) {
    console.error('❌ Error during shutdown:', error.message);
    process.exit(1);
  }
});

// Start the server
startServer();

module.exports = app;
